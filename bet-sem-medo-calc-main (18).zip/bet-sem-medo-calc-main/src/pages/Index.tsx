
import SurebetCalculator from "@/components/SurebetCalculator";
import { ApostaBoostedCalculator } from "@/components/ApostaBoostedCalculator";

const Index = () => {
  return <SurebetCalculator />;
};

export default Index;
